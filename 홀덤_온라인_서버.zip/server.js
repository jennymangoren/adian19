
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 8080;
const rooms = new Map();

function send(ws, obj){
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}
function roomCode(){
  let c;
  do c = crypto.randomBytes(3).toString("hex").toUpperCase();
  while(rooms.has(c));
  return c;
}
function broadcast(room, obj){
  for(const p of room.players) send(p.ws, obj);
}
function upgrade(req, socket){
  const key = req.headers["sec-websocket-key"];
  if(!key){ socket.destroy(); return; }
  const accept = crypto.createHash("sha1")
    .update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest("base64");
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n"+
    "Upgrade: websocket\r\nConnection: Upgrade\r\n"+
    "Sec-WebSocket-Accept: "+accept+"\r\n\r\n"
  );
}

function frame(payload){
  const b=Buffer.from(payload);
  let h;
  if(b.length<126) h=Buffer.from([0x81,b.length]);
  else if(b.length<65536){
    h=Buffer.alloc(4); h[0]=0x81; h[1]=126; h.writeUInt16BE(b.length,2);
  } else {
    h=Buffer.alloc(10); h[0]=0x81; h[1]=127; h.writeBigUInt64BE(BigInt(b.length),2);
  }
  return Buffer.concat([h,b]);
}

function parseFrames(buf){
  const out=[]; let o=0;
  while(buf.length-o>=2){
    const b1=buf[o], b2=buf[o+1];
    let len=b2&127, h=2;
    if(len===126){if(buf.length-o<4)return [out,buf.slice(o)];len=buf.readUInt16BE(o+2);h=4}
    else if(len===127){if(buf.length-o<10)return [out,buf.slice(o)];len=Number(buf.readBigUInt64BE(o+2));h=10}
    const masked=!!(b2&128);
    if(masked)h+=4;
    if(buf.length-o<h+len)return [out,buf.slice(o)];
    let p=buf.slice(o+h,o+h+len);
    if(masked){
      const k=buf.slice(o+h-4,o+h);
      for(let i=0;i<p.length;i++)p[i]^=k[i%4];
    }
    if((b1&0x0f)===8)return [out,null];
    if((b1&0x0f)===1)out.push(p.toString());
    o+=h+len;
  }
  return [out,buf.slice(o)];
}

const server=http.createServer((req,res)=>{
  if(req.url==="/health"){res.writeHead(200,{"content-type":"text/plain"});return res.end("OK")}
  const file=path.join(__dirname,"홀덤 연습장_온라인.html");
  if(req.url==="/" || req.url==="/index.html"){
    if(fs.existsSync(file)){res.writeHead(200,{"content-type":"text/html; charset=utf-8"});return res.end(fs.readFileSync(file))}
  }
  res.writeHead(404);res.end("Not found");
});

server.on("upgrade",(req,socket)=>{
  upgrade(req,socket);
  let room=null, player=null, buffer=Buffer.alloc(0);
  socket.on("data",chunk=>{
    buffer=Buffer.concat([buffer,chunk]);
    const [msgs,rest]=parseFrames(buffer); buffer=rest||Buffer.alloc(0);
    for(const raw of msgs){
      let m; try{m=JSON.parse(raw)}catch{continue}
      if(m.type==="create"){
        const code=roomCode();
        room={code,players:[],state:null};
        rooms.set(code,room);
        player={id:crypto.randomUUID(),name:m.name||"플레이어",ws:socket};
        room.players.push(player);
        send(socket,{type:"welcome",playerId:player.id});
        send(socket,{type:"room",room:code,players:room.players.map(p=>({id:p.id,name:p.name}))});
      }
      else if(m.type==="join"){
        room=rooms.get(String(m.room||"").toUpperCase());
        if(!room || room.players.length>=3){send(socket,{type:"error",message:"방이 없거나 인원이 가득 찼습니다."});continue}
        player={id:crypto.randomUUID(),name:m.name||"플레이어",ws:socket};
        room.players.push(player);
        send(socket,{type:"welcome",playerId:player.id});
        broadcast(room,{type:"room",room:room.code,players:room.players.map(p=>({id:p.id,name:p.name}))});
        if(room.state) send(socket,{type:"state",game:room.state,playerId:player.id});
      }
      else if(m.type==="state" && room && player){
        room.state=m.game;
        broadcast(room,{type:"state",game:room.state});
      }
      else if(m.type==="action" && room && player){
        // 서버는 액션을 모든 참가자에게 중계한다.
        broadcast(room,{type:"action",playerId:player.id,action:m.action});
      }
    }
  });
  socket.on("close",()=>{
    if(room&&player){
      room.players=room.players.filter(p=>p.ws!==socket);
      if(room.players.length===0)rooms.delete(room.code);
      else broadcast(room,{type:"room",room:room.code,players:room.players.map(p=>({id:p.id,name:p.name}))});
    }
  });
});

server.listen(PORT,()=>console.log(`홀덤 온라인 서버: http://localhost:${PORT}`));
